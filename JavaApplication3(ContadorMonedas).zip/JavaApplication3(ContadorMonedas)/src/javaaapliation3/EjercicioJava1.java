package javaaapliation3;
import java.util.Scanner;

/**
 *
 * @author cande
 */
public class EjercicioJava1 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int cantidad50, cantidad100, cantidad200, cantidad500, valorTotal;
        System.out.println("*------------------------------------------*");
        System.out.println("* Bienvenido al contador de monedas");
        System.out.println("*------------------------------------------*");
        System.out.print("Introduce la cantidad de monedas de 50 --> ");
        cantidad50 = input.nextInt();
        System.out.println("");
        System.out.print("Introduce la cantidad de monedas de 100 -->");
        cantidad100 = input.nextInt();
        System.out.println("");
        System.out.print("Introduce la cantidad de monedas de 200 -->");
        cantidad200 = input.nextInt();
        System.out.println("");
        System.out.print("Introduce la cantidad de monedas de 500 -->");
        cantidad500 = input.nextInt();
        System.out.println("");
        valorTotal = (cantidad50*50)+(cantidad100*100)+(cantidad200*200)+(cantidad500*500);
        System.out.println("El valor total del monto es: $"+ valorTotal+ " COP");
    }
    
}
