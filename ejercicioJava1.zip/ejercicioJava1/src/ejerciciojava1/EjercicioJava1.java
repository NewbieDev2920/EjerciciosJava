package ejerciciojava1;
import java.util.Scanner;

/**
 *
 * @author cande
 */
public class EjercicioJava1 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("CONVERSOR DE MINUTOS");
        System.out.println("*------------------------------------------*");
        System.out.println("Introduce la cantidad de minutos(Sin decimales) para ver su equivalencia en otras unidades de tiempo: ");
        System.out.print("--> ");
        int min = input.nextInt();
        System.out.println("*------------------------------------------*");
        double meses, semanas, dias, horas;
        horas = (double)min/60;
        dias = (double)min/1440;
        semanas = (double)min/10080;
        meses = (double)min/43800;
        
        System.out.println("Meses - "+ meses);
        System.out.println("Dias - "+ dias);
        System.out.println("Semanas - "+ semanas);
        System.out.println("Horas - "+ horas);
    }
    
}
