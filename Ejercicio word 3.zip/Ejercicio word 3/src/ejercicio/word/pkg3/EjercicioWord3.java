package ejercicio.word.pkg3;

// @author JUAN BENAVIDES
import java.util.Scanner;
public class EjercicioWord3 {

    
    public static void main(String[] args) {
     Scanner rd = new Scanner(System.in);
     float par_1, par_2, ex_fin, lab_1, lab_2, lab_3, tall_1, tall_2, tall_3, tall_4, tall_5, not_par, not_tall, not_lab, not_fin, not_def ;
        System.out.println("ingrese la nota del parcial #1");
        par_1=rd.nextFloat();
        System.out.println("ingrese la nota del parcial #2");
        par_2=rd.nextFloat();
        System.out.println("ingrese la nota del examen final");
        ex_fin=rd.nextFloat();
        System.out.println("ingrese las notas de los laboratorios");
        lab_1=rd.nextFloat();
        lab_2=rd.nextFloat();
        lab_3=rd.nextFloat();
        System.out.println("ingrese las notas de los talleres");
        tall_1=rd.nextFloat();
        tall_2=rd.nextFloat();
        tall_3=rd.nextFloat();
        tall_4=rd.nextFloat();
        tall_5=rd.nextFloat();
        not_par=(float)(par_1*0.20)+(float)(par_2*0.20);
        not_tall=(float)((tall_1+tall_2+tall_3+tall_4+tall_5/5)*0.15);
        not_lab=(float)((lab_1+lab_2+lab_3/3)*0.20);
        not_fin=(float)(ex_fin*0.25);
        not_def=not_par+not_tall+not_lab+not_fin;        
        System.out.println("su notal final es de: "+not_def);
    }
    

}
