package ejercicio.secuencial.pkg1;

// @author JUAN BENAVIDES
import java.util.Scanner;
public class EjercicioSecuencial1 {

    
    public static void main(String[] args) {
       
        float cap_inv, gan;
       Scanner rd=new Scanner(System.in);
        System.out.println("ingrese la cantidad a invertir");
       cap_inv=rd.nextFloat();
       gan=(float)(cap_inv*0.02);
        System.out.println("su ganancia es de: "+gan);
    }

}
