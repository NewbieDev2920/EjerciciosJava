package ejercicio.secuencial.pkg2;

// @author JUAN BENAVIDES
import java.util.Scanner;
public class EjercicioSecuencial2 {

    
    public static void main(String[] args) {
        Scanner rd =new Scanner(System.in);
            float sb, v1, v2, v3, tot_vta, com, trec; 
            System.out.println("ingrese su sueldo base");
            sb = rd.nextFloat();
           System.out.println("ingrese el valor de la venta numero #1");
           v1 = rd.nextFloat();
           System.out.println("ingrese el valor de la venta numero #2"); 
           v2 = rd.nextFloat();
           System.out.println("ingrese el valor de la venta numero #3");
           v3 = rd.nextFloat();
            tot_vta = v1+v2+v3;
            com = (float)(tot_vta*0.10);
            trec = sb+com;
            System.out.println("el total que recibe al final del mes es de "+trec);
            System.out.println("la comicion es de "+com);
            
    }

}
