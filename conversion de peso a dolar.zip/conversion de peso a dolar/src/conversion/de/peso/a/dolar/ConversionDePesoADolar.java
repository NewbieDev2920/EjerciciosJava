
package conversion.de.peso.a.dolar;

import java.util.Scanner;

/**
 *
 * @author jesus
 */
public class ConversionDePesoADolar {

  
    public static void main(String[] args) {
        float moneda_C, v_dolar, dolares;
        Scanner entrada= new Scanner(System.in);
        System.out.println("Ingrese la cantidad de dinero en pesos Colombianos: ");
        moneda_C = entrada.nextFloat();
        System.out.println("Ingrese el valor de un dolar en pesos Colombianos: ");
        v_dolar = entrada.nextFloat();
        dolares = (1 / v_dolar) *moneda_C;
        System.out.println("equivalente a dolares: "+ dolares);
    }
    
}
