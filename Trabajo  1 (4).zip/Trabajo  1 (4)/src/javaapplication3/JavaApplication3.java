
package javaapplication3;

import java.util.Scanner;

/**
 *
 * @author jesus
 */
public class JavaApplication3 {

   
    public static void main(String[] args) {
        float c1, c2, c3, ef, tf, prom, ppar, pef, ptf, cf;
        Scanner entrada= new Scanner(System.in);
        System.out.println("Por favor indique valor calificacion 1");
        c1= entrada.nextFloat();
        System.out.println("Por favor indique valor calificacion 2");
        c2= entrada.nextFloat();
        System.out.println("Por favor indique valor calificacion 3");
        c3= entrada.nextFloat();
        System.out.println("favor dijite resultado examen final");
        ef= entrada.nextFloat();
        System.out.println("favor dijite resultado trabajo final");
        tf= entrada.nextFloat();      
        prom= (c1+c2+c3)/3;
        ppar= prom*0.55f;
        pef= ef *0.30f;
        ptf= tf *0.15f; 
        cf= ppar+pef+ptf;
        System.out.println("resultado final: "+cf);
        
    }
    
}
