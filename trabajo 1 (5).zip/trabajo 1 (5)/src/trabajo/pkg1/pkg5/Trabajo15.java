
package trabajo.pkg1.pkg5;

import java.util.Scanner;

/**
 *
 * @author jesus
 */
public class Trabajo15 {

    public static void main(String[] args) {
        float nh, nm, ta, ph, pm;
        Scanner entrada= new Scanner(System.in);
        System.out.println("por favor indicar numeros de hombres");
        nh= entrada.nextFloat();
        System.out.println("por favor indique numero de mujeres ");
        nm= entrada.nextFloat();
        ta= nh+nm;
        ph= nh*100/ta;
        pm= nm*100/ta;
        System.out.println ("promedio de hombres es: " +ph +"%");
        System.out.println ("promedio de mujeres es: " +pm + "%");
        
        
       
    }
    
}
