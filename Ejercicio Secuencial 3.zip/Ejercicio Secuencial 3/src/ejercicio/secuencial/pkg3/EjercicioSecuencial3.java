package ejercicio.secuencial.pkg3;

// @author JUAN BENAVIDES
import java.util.Scanner;
public class EjercicioSecuencial3 {

    
    public static void main(String[] args) {
        Scanner rd = new Scanner(System.in);
        float tc, des, tp;
        System.out.println("ingrese el valor de la compra");
        tc= rd.nextInt();
        des=(float)(tc*0.15);
        tp=tc-des;
        System.out.println("su compra con el 15% de descuento queda en "+tp);
        
    }

}
