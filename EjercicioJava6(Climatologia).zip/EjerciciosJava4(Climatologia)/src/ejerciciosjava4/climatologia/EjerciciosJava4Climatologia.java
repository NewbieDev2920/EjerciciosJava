package ejerciciosjava4.climatologia;

import java.util.Scanner;

/**
 *
 * @author Benavides Juan, Ordosgoitia Jesus, Dela Rosa Carlos
 */
public class EjerciciosJava4Climatologia {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        float celsius, fahrenheit;
        System.out.println("*----------------------------------------------------*");
        System.out.println("*Bienvenido al conversor de celsius a fahrenheit");
        System.out.println("*----------------------------------------------------*");
        System.out.print("Introduzca la temperatura en celsius --> ");
        celsius = input.nextFloat();
        fahrenheit = (float) ((1.8*celsius)+32);
        System.out.println("El equivalente es: "+ fahrenheit +" grados fahrenheit.");
    }
    
}
