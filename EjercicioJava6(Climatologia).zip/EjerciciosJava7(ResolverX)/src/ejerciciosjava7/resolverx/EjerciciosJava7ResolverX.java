
package ejerciciosjava7.resolverx;

import java.util.Scanner;

/**
 *
 * @author Benavides Juan, Ordosgoitia Jesus, Dela Rosa Carlos
 */
public class EjerciciosJava7ResolverX {

   
    public static void main(String[] args) {
       double coeficienteA, coeficienteB, coeficienteC, X1, X2;
       Scanner input = new Scanner(System.in);
       System.out.println("*------------------------------------------*");
       System.out.println("* Bienvenido a la calculadora para resolver X");
       System.out.println("*------------------------------------------*");
       System.out.println("Dada una ecuacion grado 2 igualada a 0 introduzca sus coeifcientes: ");
       System.out.print("A -->");
       coeficienteA = input.nextFloat();
       System.out.print("B -->");
       coeficienteB = input.nextFloat();
       System.out.print("C -->");
       coeficienteC = input.nextFloat();
       X1 = (-coeficienteB+Math.sqrt(Math.pow(coeficienteB,2)-4*coeficienteA*coeficienteC))/2*coeficienteA;
       X2 = (-coeficienteB-Math.sqrt(Math.pow(coeficienteB,2)-4*coeficienteA*coeficienteC))/2*coeficienteA;
       System.out.println("X1 es igual a --> "+ X1 );
       System.out.println("X2 es igual a --> "+ X2 );
    }
    
}
