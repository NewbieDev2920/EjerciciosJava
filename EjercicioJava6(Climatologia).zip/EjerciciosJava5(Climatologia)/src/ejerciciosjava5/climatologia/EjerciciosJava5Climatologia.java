
package ejerciciosjava5.climatologia;

import java.util.Scanner;

/**
 *
 * @author Benavides Juan, Ordosgoitia Jesus, Dela Rosa Carlos
 */
public class EjerciciosJava5Climatologia {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double fahrenheit, celsius;
        System.out.println("*----------------------------------------------------*");
        System.out.println("*Bienvenido al conversor de fahrenheit a celsius");
        System.out.println("*----------------------------------------------------*");
        System.out.print("Introduzca la temperatura en fahrenheit --> ");
        fahrenheit = input.nextDouble();
        celsius = (fahrenheit-32)*5/9;
        System.out.println("El equivalente es: "+ celsius +" grados celsius.");
    }
    
}
