
package ejerciciojava6.climatologia;

import java.util.Scanner;

/**
 *
 * @author Benavides Juan, Ordosgoitia Jesus, Dela Rosa Carlos
 */
public class EjercicioJava6Climatologia {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double pulgada, milimetro;
        System.out.println("*----------------------------------------------------*");
        System.out.println("*Bienvenido al conversor de pulgadas a milimetros");
        System.out.println("*----------------------------------------------------*");
        System.out.print("Introduzca las pulgadas --> ");
        pulgada = input.nextDouble();
        milimetro = pulgada*25.5 ;
        System.out.println("El equivalente es: "+ milimetro +" milimetros.");
    }
    
}
